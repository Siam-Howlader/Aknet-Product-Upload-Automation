Product Category Ancestor Assignment for OpenCart 3.0.3.8
Version 1.0.1

When products are added or edited through the standard admin product model, selected category IDs are expanded using OpenCart's category_path table. Selecting Accessories > Backpack > ASUS assigns the product to ASUS, Backpack, and Accessories. IDs are deduplicated before OpenCart writes the product-to-category links.

Upgrade / installation
1. Remove the previously installed Product Category Ancestor Assignment modification/package if present.
2. In OpenCart admin, open Extensions > Installer and upload this ZIP.
3. Open Extensions > Modifications and click Refresh.

This does not create categories or change the category autocomplete. OpenCart's standard edit flow replaces the submitted category links; this modification expands the submitted list before that save.
