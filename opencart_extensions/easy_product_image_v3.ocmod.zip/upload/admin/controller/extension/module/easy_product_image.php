<?php
class ControllerExtensionModuleEasyProductImage extends Controller {
    public function upload() {
        $this->load->language('extension/module/easy_product_image');

        $json = array();

        if (!$this->user->hasPermission('modify', 'catalog/product')) {
            $json['error'] = $this->language->get('error_permission');
            return $this->response->setOutput(json_encode($json));
        }

        $this->load->model('tool/image');

        if (!empty($this->request->post['image_url'])) {
            $tmp = $this->downloadImage($this->request->post['image_url']);
            if (!$tmp) {
                $json['error'] = $this->language->get('error_easy_image_process');
                return $this->response->setOutput(json_encode($json));
            }
            $sourceName = basename(parse_url($this->request->post['image_url'], PHP_URL_PATH));
            $result = $this->processImage($tmp, $sourceName, $this->request->post['product_name'] ?? 'product');
            @unlink($tmp);
        } else {
            if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
                $json['error'] = $this->language->get('error_easy_image_process');
                return $this->response->setOutput(json_encode($json));
            }
            $file = $_FILES['file'];
            $mime = $this->detectMime($file['tmp_name']);
            if (!in_array($mime, array('image/jpeg', 'image/webp'), true)) {
                $json['error'] = $this->language->get('error_easy_image_filetype');
                return $this->response->setOutput(json_encode($json));
            }
            $result = $this->processImage($file['tmp_name'], $file['name'], $this->request->post['product_name'] ?? 'product');
        }

        if (!$result) {
            $json['error'] = $this->language->get('error_easy_image_process');
        } else {
            $json = $result;
        }

        $this->response->setOutput(json_encode($json));
    }

    private function detectMime($file) {
        if (function_exists('finfo_open')) {
            $f = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_file($f, $file);
            finfo_close($f);
            return $mime;
        }
        $info = @getimagesize($file);
        return $info && !empty($info['mime']) ? $info['mime'] : '';
    }

    private function processImage($sourceFile, $originalName, $productName) {
        $mime = $this->detectMime($sourceFile);
        if (!in_array($mime, array('image/jpeg', 'image/webp'), true)) return false;

        $source = $this->createImage($sourceFile, $mime);
        if (!$source) return false;

        $width = imagesx($source);
        $height = imagesy($source);
        if ($width < 1 || $height < 1) { imagedestroy($source); return false; }

        // Keep original dimensions. OpenCart can generate its thumbnails later.
        $canvas = imagecreatetruecolor($width, $height);
        $white = imagecolorallocate($canvas, 255, 255, 255);
        imagefill($canvas, 0, 0, $white);
        imagealphablending($source, true);
        imagecopy($canvas, $source, 0, 0, 0, 0, $width, $height);
        imagedestroy($source);

        $dir = DIR_IMAGE . 'catalog/easy_product_image/';
        if (!is_dir($dir) && !@mkdir($dir, 0755, true)) { imagedestroy($canvas); return false; }

        $base = $this->slug($productName);
        if ($base === '') $base = 'product';
        $base .= '-' . date('Ymd-His') . '-' . bin2hex(random_bytes(3));
        $filename = $base . '.jpg';
        $path = $dir . $filename;

        if (!imagejpeg($canvas, $path, 90)) { imagedestroy($canvas); return false; }
        imagedestroy($canvas);

        $relative = 'catalog/easy_product_image/' . $filename;
        $thumb = $this->model_tool_image->resize($relative, 100, 100);

        return array(
            'success' => $this->language->get('text_easy_image_uploaded'),
            'filename' => $filename,
            'path' => $relative,
            'thumb' => $thumb
        );
    }

    private function createImage($file, $mime) {
        if ($mime === 'image/jpeg' && function_exists('imagecreatefromjpeg')) {
            return @imagecreatefromjpeg($file);
        }
        if ($mime === 'image/webp' && function_exists('imagecreatefromwebp')) {
            return @imagecreatefromwebp($file);
        }

        // Optional Imagick fallback for WebP when GD WebP support is unavailable.
        if ($mime === 'image/webp' && class_exists('Imagick')) {
            try {
                $im = new Imagick($file);
                $im->setIteratorIndex(0);
                $im->setImageFormat('png');
                $blob = $im->getImageBlob();
                $im->clear();
                $im->destroy();
                return @imagecreatefromstring($blob);
            } catch (Exception $e) {
                return false;
            }
        }
        return false;
    }

    private function downloadImage($url) {
        if (!filter_var($url, FILTER_VALIDATE_URL)) return false;
        $scheme = strtolower(parse_url($url, PHP_URL_SCHEME));
        if (!in_array($scheme, array('http', 'https'), true)) return false;

        $context = stream_context_create(array('http' => array('timeout' => 20, 'follow_location' => 1, 'user_agent' => 'OpenCart Easy Product Image')));
        $data = @file_get_contents($url, false, $context);
        if ($data === false || strlen($data) === 0) return false;
        $tmp = tempnam(sys_get_temp_dir(), 'easyimg_');
        if ($tmp === false || @file_put_contents($tmp, $data) === false) return false;
        return $tmp;
    }

    private function slug($value) {
        $value = html_entity_decode((string)$value, ENT_QUOTES, 'UTF-8');
        $value = preg_replace('/[^A-Za-z0-9]+/', '-', $value);
        return trim(strtolower($value), '-');
    }
}
