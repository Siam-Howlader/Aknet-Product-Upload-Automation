Easy Product Image Upload for OpenCart 3.x
Version 1.2.0
==========================================

Features
- Select/drag multiple local JPG/JPEG and WebP images
- First selected image becomes the OpenCart main product image by default
- Any uploaded additional image can be promoted to the main image with the “Make main” button
- Promoting an image swaps the previous main image into the additional-image row, preserving both images
- Remaining selected images become additional product images
- WebP is converted to JPEG before saving
- Uses PHP GD WebP decoding when available, with an optional Imagick WebP fallback
- Preserves selected upload order
- Auto-generated safe JPEG filenames
- Drag rows to reorder additional images
- Direct image URL support

Install
1. In Admin go to Extensions > Installer
2. Upload easy_product_image.ocmod.zip
3. Go to Extensions > Modifications and click Refresh
4. Refresh the Theme/Sass cache from Dashboard > Developer Settings if available
5. Edit a product and open the Image tab

Requirements
- OpenCart 3.0.x
- PHP GD with JPEG support
- For WebP: PHP GD WebP support OR PHP Imagick with WebP support
- Product name must be filled in before local image upload

Important
- Only JPG/JPEG and WebP are accepted for local uploads.
- All uploaded images are saved as JPEG files under image/catalog/easy_product_image/.
- The first selected local image is assigned to the standard OpenCart main image field by default. Subsequent images are assigned to product_image additional-image rows. Use “Make main” beside any additional image to promote it; the previous main image is swapped into that row so images are not lost.

If WebP still fails, check that either imagecreatefromwebp() exists in PHP GD or Imagick is installed with WebP support.
